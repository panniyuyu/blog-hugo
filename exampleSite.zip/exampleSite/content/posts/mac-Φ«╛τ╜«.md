---
title: mac 设置
author: YyWang
authorLink: http://www.yywang.top
date: 2019-08-13T16:44:33+08:00
lastmod: 2019-08-13T16:44:33+08:00
draft: false
tags: ["mac"]
categories: ["mac"]
featuredImagePreview: 
---
###### 外接键盘的调整
键盘设置中将control和command互换就可以达到和Windows下的复制粘贴时一样的，切换程序则由alt+tab变成了ctrl+tab需要适应一下，不过复制，粘贴，撤销，保存这些不用再去适应新的快捷键了
![upload successful](/images/pasted-14.png)
###### idea中的调整
preferences中找到keymap选择Eclipse(macOS)，这样加上第一步的配置复制粘贴这些快捷键与Windows相同，不用再去适应新的快捷键

###### 自动补全变量
keymap中搜索variable   默认为：option+command+L 通过以上设置后为：Ctrl+alt+L



##### 另一种使用方法
不做任何配置，idea中使用eclipse风格的快捷键，idea中的使用不影响，但是在idea以外就得适应mac中的快捷键，感觉还是这个方法更容易接受一些
