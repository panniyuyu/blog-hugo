
---
title: 
---

* 欢迎各位大佬互相交流 sbsbjs@qq.com
* since 2021-01-29 准备入坑云原生，先收藏几个大佬的博客
* [云原生实验室](https://fuckcloudnative.io/)
* [阳明的博客](https://www.qikqiak.com/)
* [kuboard for k8s](https://kuboard.cn/)
